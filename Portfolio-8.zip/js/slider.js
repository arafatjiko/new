// Hover Effect Script
$(document).ready(function(){
	$("#click-1").click(function(){
		$("#click-1 > span").addClass("open");
		$("#click-2 > span, #click-3 > span").removeClass("open");
	});
	$("#click-2").click(function(){
		$("#click-2 > span").addClass("open");
		$("#click-1 > span, #click-3 > span").removeClass("open");
	});
	$("#click-3").click(function(){
		$("#click-3 > span").addClass("open");
		$("#click-2 > span, #click-1 > span").removeClass("open");
	});
})
// Hover Effect Script
$(document).ready(function(){
	$("#click-s-1").click(function(){
		$("#click-s-1 > span").addClass("open");
		$("#click-s-2 > span, #click-s-3 > span").removeClass("open");
	});
	$("#click-s-2").click(function(){
		$("#click-s-2 > span").addClass("open");
		$("#click-s-1 > span, #click-s-3 > span").removeClass("open");
	});
	$("#click-s-3").click(function(){
		$("#click-s-3 > span").addClass("open");
		$("#click-s-2 > span, #click-s-1 > span").removeClass("open");
	});
})




// Slide Effect Script
$(document).ready(function(){
	$("#click-1").click(function(){
		$("#slide-1").css({"display": "block", "opacity": "1"});
		$("#slide-3, #slide-2").css ({"display": "none", "opacity": "0"});
	});
});
$(document).ready(function(){
	$("#click-2").click(function(){
		$("#slide-2").css({"display": "block", "opacity": "1"});
		$("#slide-1, #slide-3").css ({"display": "none", "opacity": "0"});
	});
});
$(document).ready(function(){
	$("#click-3").click(function(){
		$("#slide-3").css({"display": "block", "opacity": "1"});
		$("#slide-1, #slide-2").css ({"display": "none", "opacity": "0"});
	});
});

// Slide Effect Script
$(document).ready(function(){
	$("#click-s-1").click(function(){
		$("#slide-1").css({"display": "block", "opacity": "1"});
		$("#slide-3, #slide-2").css ({"display": "none", "opacity": "0"});
	});
});
$(document).ready(function(){
	$("#click-s-2").click(function(){
		$("#slide-2").css({"display": "block", "opacity": "1"});
		$("#slide-1, #slide-3").css ({"display": "none", "opacity": "0"});
	});
});
$(document).ready(function(){
	$("#click-s-3").click(function(){
		$("#slide-3").css({"display": "block", "opacity": "1"});
		$("#slide-1, #slide-2").css ({"display": "none", "opacity": "0"});
	});
});